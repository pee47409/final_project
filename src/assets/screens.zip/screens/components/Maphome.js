import React, { Component } from 'react';
import Map from './Map';

class Home extends Component {
    render() {
        return (
            <div style={{margin:'50px'}}>
                <Map
                    google={this.props.google}
                    center={{ lat: 13.736717, lng: 100.523186 }}
                    height='700px'
                    zoom={13}
                />
            </div>
        );
    }
}

export default Home;