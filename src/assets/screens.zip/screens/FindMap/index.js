import React from "react"
import { Row, Col, Button, Form } from 'react-bootstrap'
import GoogleMapReact from 'google-map-react';
function Map() {
  const [showMain, setShowMain] = React.useState(true)
  const onClickMap = () =>{
    showMain ? setShowMain(false) : setShowMain(true)
  }

  return (
    <div style={{backgroundColor:"#66BECC",height:"100vh"}}>
    {showMain ? 

    <Row className="w-100" style={{backgroundColor:"#66BECC",margin:0}}>
   <Row className="w-100" style={{backgroundColor:"#66BECC",margin:0}}>
   <Col sm  className="d-flex justify-content-center align-items-center">
     <p className="h1" style={{color:"white"}}>
     Pramern Real-Estate Investor Tools
     </p>
     </Col>
   </Row>
  <Col sm className="d-flex justify-content-center align-items-center" >
<div style={{  padding: '20px', width: "600px",backgroundColor:"white",borderRadius:20, boxShadow: "5px 5px 10px #9E9E9E" }}>
  <Row>
    <Col>
      <Row>
        <Col>
          จังหวัด:
  </Col>
        <Col>
          <Form>
            <Form.Group controlId="exampleForm.SelectCustom">

              <Form.Control as="select" custom>
                <option>1</option>
                <option>2</option>
                <option>3</option>
                <option>4</option>
                <option>5</option>
              </Form.Control>
            </Form.Group>
          </Form>
        </Col>
      </Row>
      <br />
      <Row>
        <Col>
          ทางเข้า-ออก:
  </Col>
        <Col>
          <Form>
            <Form.Group controlId="exampleForm.SelectCustom">

              <Form.Control as="select" custom>
                <option>1</option>
                <option>2</option>
                <option>3</option>
                <option>4</option>
                <option>5</option>
              </Form.Control>
            </Form.Group>
          </Form>
        </Col>
      </Row>
      <br />
      <Row>
        <Col>
          <p>อาณาเขตติดต่อ:</p>

        </Col>
        <Col>
          <Form>
            <Form.Group controlId="exampleForm.SelectCustom">

              <Form.Control as="select" custom>
                <option>1</option>
                <option>2</option>
                <option>3</option>
                <option>4</option>
                <option>5</option>
              </Form.Control>
            </Form.Group>
          </Form>
        </Col>
      </Row><br />
      <Row>
        <Col>
          สาธารณูปโภค:
  </Col>
        <Col>
          <Form>
            <Form.Group controlId="exampleForm.SelectCustom">

              <Form.Control as="select" custom>
                <option>1</option>
                <option>2</option>
                <option>3</option>
                <option>4</option>
                <option>5</option>
              </Form.Control>
            </Form.Group>
          </Form>
        </Col>
      </Row><br />
      <Row>
        <Col>
          การใช้ประโยชน์:
  </Col>
        <Col>
          <Form>
            <Form.Group controlId="exampleForm.SelectCustom">

              <Form.Control as="select" custom>
                <option>1</option>
                <option>2</option>
                <option>3</option>
                <option>4</option>
                <option>5</option>
              </Form.Control>
            </Form.Group>
          </Form>
        </Col>
      </Row><br />
      <Row>
        <Col>
          สิ่งแวดล้อม:
  </Col>
        <Col>
          <Form>
            <Form.Group controlId="exampleForm.SelectCustom">

              <Form.Control as="select" custom>
                <option>1</option>
                <option>2</option>
                <option>3</option>
                <option>4</option>
                <option>5</option>
              </Form.Control>
            </Form.Group>
          </Form>
        </Col>
      </Row><br />

      <Row>
        <Col>
        <Button variant="success" className='w-100'>SUBMIT</Button>{' '}
        </Col>
      </Row><br />
      <Row>
        <Col>
        <Button variant="primary" className='w-100' onClick={onClickMap}>FIND ON MAP :)</Button>{' '}
        </Col>
      </Row><br />
      <Row>
        <Col>
        <Button variant="danger" className='w-100' href="/">Home</Button>
        </Col>
      </Row>

    </Col>
  </Row>

</div>
</Col>

    </Row>
    
       :
       
       <Row className="w-100" style={{backgroundColor:"#F7F7F7"}}>
       <Col sm={8} style={{height: "100vh"}}>
         <GoogleMapReact
         bootstrapURLKeys={{ key:"AIzaSyC4rXwXvSbKJ7NCT7EZnQ334Ef4EUTFEo0"}}
         defaultCenter={{
           lat: 13.736717,
           lng: 100.523186
         }}
         defaultZoom={7}
        
       >


       </GoogleMapReact>
       </Col>
       <Col sm={4} className="d-flex justify-content-center align-items-center" style={{  height: "100vh" }}>

         <div style={{  padding: '20px', width: "80%",backgroundColor:"white",borderRadius:20, boxShadow: "5px 5px 10px #9E9E9E" }}>
           <Row>
             <Col>
               <Row>
                 <Col>
                   จังหวัด:
           </Col>
                 <Col>
                   <Form>
                     <Form.Group controlId="exampleForm.SelectCustom">

                       <Form.Control as="select" custom>
                         <option>1</option>
                         <option>2</option>
                         <option>3</option>
                         <option>4</option>
                         <option>5</option>
                       </Form.Control>
                     </Form.Group>
                   </Form>
                 </Col>
               </Row>
               <br />
               <Row>
                 <Col>
                   ทางเข้า-ออก:
           </Col>
                 <Col>
                   <Form>
                     <Form.Group controlId="exampleForm.SelectCustom">

                       <Form.Control as="select" custom>
                         <option>1</option>
                         <option>2</option>
                         <option>3</option>
                         <option>4</option>
                         <option>5</option>
                       </Form.Control>
                     </Form.Group>
                   </Form>
                 </Col>
               </Row>
               <br />
               <Row>
                 <Col>
                   <p>อาณาเขตติดต่อ:</p>

                 </Col>
                 <Col>
                   <Form>
                     <Form.Group controlId="exampleForm.SelectCustom">

                       <Form.Control as="select" custom>
                         <option>1</option>
                         <option>2</option>
                         <option>3</option>
                         <option>4</option>
                         <option>5</option>
                       </Form.Control>
                     </Form.Group>
                   </Form>
                 </Col>
               </Row><br />
               <Row>
                 <Col>
                   สาธารณูปโภค:
           </Col>
                 <Col>
                   <Form>
                     <Form.Group controlId="exampleForm.SelectCustom">

                       <Form.Control as="select" custom>
                         <option>1</option>
                         <option>2</option>
                         <option>3</option>
                         <option>4</option>
                         <option>5</option>
                       </Form.Control>
                     </Form.Group>
                   </Form>
                 </Col>
               </Row><br />
               <Row>
                 <Col>
                   การใช้ประโยชน์:
           </Col>
                 <Col>
                   <Form>
                     <Form.Group controlId="exampleForm.SelectCustom">

                       <Form.Control as="select" custom>
                         <option>1</option>
                         <option>2</option>
                         <option>3</option>
                         <option>4</option>
                         <option>5</option>
                       </Form.Control>
                     </Form.Group>
                   </Form>
                 </Col>
               </Row><br />
               <Row>
                 <Col>
                   สิ่งแวดล้อม:
           </Col>
                 <Col>
                   <Form>
                     <Form.Group controlId="exampleForm.SelectCustom">

                       <Form.Control as="select" custom>
                         <option>1</option>
                         <option>2</option>
                         <option>3</option>
                         <option>4</option>
                         <option>5</option>
                       </Form.Control>
                     </Form.Group>
                   </Form>
                 </Col>
               </Row><br />

               <Row>
                 <Col>
                 <Button variant="success" className='w-100'>SUBMIT</Button>{' '}
                 </Col>
               </Row><br />
          
        <Row>
        <Col>
        <Button variant="primary" className='w-100' onClick={onClickMap}>CLOSE</Button>{' '}
        </Col>
        </Row>
        
      <br />
      <Row>
        <Col>
        <Button variant="danger" className='w-100' href="/">HOME</Button>
        </Col>
      </Row>
             </Col>
           </Row>

         </div>
       </Col>
     </Row>
       
       }
    </div>
   
  );
}

export default Map;
