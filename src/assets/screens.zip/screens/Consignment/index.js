import { Row, Col, Button, Form } from 'react-bootstrap'
import imgtest from "../../images/hey.png"
import f from "../../images/Artboard 1.png"
import { ProSidebar, Menu, MenuItem, SubMenu } from 'react-pro-sidebar';
import 'react-pro-sidebar/dist/css/styles.css';
import { Link } from 'react-router-dom';
import React from "react"

function Test() {
  const [Province, setProvince] = React.useState(null)
  const [District, setDistrict] = React.useState(null)
  const [SubDistrict, setSubDistrict] = React.useState(null)
  const [Size, setSize] = React.useState(null)
  const [checkboxtype2, setcheckboxtype2] = React.useState("ที่ดินเปล่า")
  const [CityPlanColor, setCityPlanColor] = React.useState(null)
  const [Contact, setContact] = React.useState(null)
  const [Price, setPrice] = React.useState(null)
  const [Other, setOther] = React.useState(null)
  const hiddenFileInput = React.useRef(null);
  const [image, setImage] = React.useState("");
  const handleClick = (event) => {
    event.preventDefault();
    hiddenFileInput.current.click();
  };
  const handleChange = (event) => {
    event.preventDefault();
    
    setImage(URL.createObjectURL(event.target.files[0]));
    
  };
  

  const clickAgree = () => {


  

    if (Province != null && District != null && SubDistrict != null && CityPlanColor  != null && Size != null  && checkboxtype2 != null && Contact != null&& Price  != null&&   Other  != null) {

      console.log(Province)
      console.log(District)
      console.log(SubDistrict)
      console.log(CityPlanColor)
      console.log(Size)
      console.log(Contact)
      console.log(Other)
      console.log(Price)
      console.log(checkboxtype2)

    }
    else {
      alert("Please fill all information")
    }


  }

  const clickCancel = () => {
    setProvince(null)
    setSubDistrict(null)
    setDistrict(null)
    setSize(null)
    
    setContact(null)
    setCityPlanColor(null)
    setPrice(null)
    setOther(null)
  }



  return (
    <>
      <div style={{ backgroundColor: "#66BECC", height: "100vh" }}>
        <Row style={{
          margin: 0, height: "100%", backgroundImage: `url("https://sv1.picz.in.th/images/2021/04/01/DJnLX9.png")`,
        }}>
          <Col  >
            <ProSidebar style={{ margin: 0, height: '1000px', width: '100%' }}>

              <Menu iconShape="square">
                <MenuItem  >Pramern</MenuItem>
                <Link to="/" />
                <SubMenu title="MENU" >
                  <MenuItem>PROPERTY APPRAISAL<Link to="/test" /></MenuItem>
                  <MenuItem>CONSIGNMENT<Link to="/Consignment" /></MenuItem>
                  <MenuItem>CONSIGNMENT LIST<Link to="/ConsignmentLists" /></MenuItem>
                </SubMenu>
              </Menu>

            </ProSidebar>


          </Col>

          <Col sm={10} className="d-flex justify-content-center align-items-center" style={{ margin: 0, padding: 50, backgroundImage: `url("https://sv1.picz.in.th/images/2021/04/01/DJslzn.png")`, backgroundPosition: 'center', backgroundRepeat: 'no-repeat', backgroundSize: 'cover' }}>

            <div style={{ width: "100%", height: "100%", overflowY: 'scroll', backgroundColor: "#736E76", borderRadius: 10, boxShadow: "5px 5px 10px #9E9E9E", border: 'solid white' }}>
              <Row style={{ margin: 10 }}>
                <Col>
                  <p className="h1" style={{ color: 'white' }}>
                    Consignment
         </p>
                </Col>
              </Row>

              {/*ดึงข้อมูลมาจาก database */}

              <Row style={{ margin: 30, height: "200px" }}>
                <Col sm={4} style={{ height: "300px", marginTop: "4px" }}>
                  <Form.Group controlId="formBasicPassword">
                    <Form.Control style={{ marginTop: "10px" }} type="text" placeholder="Province" value={Province} onChange={(e) => { setProvince(e.target.value) }} />
                  </Form.Group>

                  <Form.Group controlId="formBasicPassword" >
                    <Form.Control style={{ marginTop: "30px" }} type="text" placeholder="District" value={District} onChange={(e) => { setDistrict(e.target.value) }} />
                  </Form.Group>

                  <Form.Group controlId="formBasicPassword" >
                    <Form.Control style={{ marginTop: "30px" }} type="text" placeholder="Sub-District" value={SubDistrict} onChange={(e) => { setSubDistrict(e.target.value) }} />
                  </Form.Group>
                  <Form.Group controlId="formBasicPassword" >
                    <Form.Control style={{ marginTop: "30px" }} type="text" placeholder="Size" value={Size} onChange={(e) => { setSize(e.target.value) }} />
                  </Form.Group>
                  <Form.Group style={{ marginTop: "30px" }}controlId="exampleForm.SelectCustom">

                      <Form.Control as="select" custom onChange={(e) => { setcheckboxtype2(e.target.value) }}>
                        <option >ที่ดินเปล่า</option>
                        <option >ที่ดินพร้อมสิ่งปลูกสร้าง</option>
                        <option >ห้องชุด</option>
                      </Form.Control>
                    </Form.Group>

                  <Form.Group controlId="formBasicPassword">
                      <Form.Control style={{ marginTop: "30px" }}type="text" placeholder="City Plan Color" value={CityPlanColor} onChange={(e) => { setCityPlanColor(e.target.value) }} />
                    </Form.Group>
                    <Form.Group controlId="formBasicPassword">
                      <Form.Control style={{ marginTop: "30px" }}type="text" placeholder="Price" value={Price} onChange={(e) => { setPrice(e.target.value) }} />
                    </Form.Group>

                  <Form.Group controlId="formBasicPassword" >
                    <Form.Control style={{ marginTop: "30px" }} type="text" placeholder="Contact" value={Contact} onChange={(e) => { setContact(e.target.value) }} />
                  </Form.Group>
                  <Form.Group controlId="formBasicPassword">
                      <Form.Control style={{ marginTop: "30px" }}type="text" placeholder="Description" value={Other} onChange={(e) => { setOther(e.target.value) }} />

                    </Form.Group>
                    

                </Col>




                <Col><div  style={{ width: "600px", height: "350px", backgroundColor: "#B6B6B6", marginLeft: '300px', marginTop: '50px', borderRadius: 10 }}>
                  <p className="h3" style={{ color: 'black', textAlign: 'center', paddingTop: '100px' }}>
                    Add Photo
         </p><br />
         <Button     style={{ marginLeft:'180px'}}
                    onClick={handleClick}
                    variant="primary"
                   
                  >
                    CHOOSE YOUR IMAGE
                  </Button>
                  <input
                    onChange={handleChange}
                    type="file"
                    ref={hiddenFileInput}
                    style={{ display: "none" }}
                  />
                </div>
                <Row style={{  marginTop: '320px' }}>

                
                  <Col  style={{ marginLeft: "50%" }}>
                  <Button style={{ width: "80%" }} onClick={clickAgree} variant="primary" type="submit">
                    Agree
                  </Button>
                  </Col>
                  <Col>
                  <Button style={{ width: "80%" }} variant="danger" type="submit" onClick={clickCancel}>
                    Cancel
                  </Button>
                  </Col>
                  </Row>
                </Col>
              </Row>
              


            </div>
          </Col>


        </Row>
      </div>
    </>
  );
}

export default Test;
