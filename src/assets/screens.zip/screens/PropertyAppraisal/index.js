import { Row, Col, Button, Form } from 'react-bootstrap'
import imgtest from "../../images/hey.png"
import f from "../../images/Artboard 1.png"
import { ProSidebar, Menu, MenuItem, SubMenu } from 'react-pro-sidebar';
import 'react-pro-sidebar/dist/css/styles.css';
import { Link } from 'react-router-dom';
import GoogleMapReact from 'google-map-react';
import React, { Component } from 'react'
import { withGoogleMap, GoogleMap, withScriptjs, InfoWindow, Marker } from "react-google-maps";

function Test() {
  const [Province, setProvince] = React.useState(null)
  const [District, setDistrict] = React.useState(null)
  const [SubDistrict, setSubDistrict] = React.useState(null)
  const [Size, setSize] = React.useState(null)
  const [checkboxtype2, setcheckboxtype2] = React.useState("ที่ดินเปล่า")
  const [CityPlanColor, setCityPlanColor] = React.useState(null)
  const [latlong, setlatlong] = React.useState(null)
  const [checkboxtype, setcheckboxtype] = React.useState("Marketapproch")




  const clickAgree = () => {



    var Checkboxtype = checkboxtype
   

    if (Province != null && District != null && SubDistrict != null && Size != null  && CityPlanColor != null && latlong != null && checkboxtype2 != null  ) {

      console.log(Province)
      console.log(District)
      console.log(SubDistrict)
      console.log(Size)
      console.log(CityPlanColor)
      console.log(latlong)
      console.log(Checkboxtype)
      console.log(checkboxtype2)

    }
    else {
      alert("Please fill all information")
    }


  }

  const clickCancel = () => {
    setProvince(null)
    setSubDistrict(null)
    setSize(null)
    setDistrict(null)
    
    setCityPlanColor(null)
  }



  return (
    <>

      <div style={{ backgroundColor: "#66BECC", height: "100vh" }}>
        <Row style={{
          margin: 0, height: "100%", backgroundImage: `url("https://sv1.picz.in.th/images/2021/04/01/DJnLX9.png")`,
        }}>
          <Col  >
            <ProSidebar style={{ margin: 0, height: '1000px', width: '100%' }}>

              <Menu iconShape="square">
                <MenuItem  >Pramern</MenuItem>
                <Link to="/" />
                <SubMenu title="MENU" >

                  <MenuItem>PROPERTY APPRAISAL<Link to="/PropertyAppraisal" /></MenuItem>
                  <MenuItem>CONSIGNMENT<Link to="/Consignment" /></MenuItem>
                  <MenuItem>CONSIGNMENT LIST<Link to="/ConsignmentLists" /></MenuItem>
                </SubMenu>
              </Menu>

            </ProSidebar>


          </Col>

          <Col sm={10} style={{ padding: 20, backgroundImage: `url("https://sv1.picz.in.th/images/2021/04/01/DJslzn.png")`, backgroundPosition: 'center', backgroundRepeat: 'no-repeat', backgroundSize: 'cover' }}>

            <div style={{ height: "650px", backgroundColor: "#736E76", borderRadius: 10, boxShadow: "5px 5px 10px #9E9E9E", border: 'solid white' }}>



              <GoogleMapReact
                bootstrapURLKeys={{ key: "AIzaSyC4rXwXvSbKJ7NCT7EZnQ334Ef4EUTFEo0" }}
                defaultCenter={{
                  lat: 13.736717,
                  lng: 100.523186
                }}
                defaultZoom={7}

              >


              </GoogleMapReact>


            </div>
            <Row sm>
              <Col sm style={{ marginTop: "15px" }}>
                <Row >
                  <Col>
                    <Form.Group controlId="formBasicPassword">

                      <Form.Control type="text" placeholder="Province" value={Province} onChange={(e) => { setProvince(e.target.value) }} />
                    </Form.Group>
                  </Col>

                  <Col>
                    <Form.Group controlId="formBasicPassword">
                      <Form.Control type="text" placeholder="District" value={District} onChange={(e) => { setDistrict(e.target.value) }} />
                    </Form.Group>
                  </Col>
                  <Col>
                    {/*ที่เว้น */}
                  </Col>
                </Row>
                <Row style={{ marginTop: "20px" }}>
                  <Col>
                    <Form.Group controlId="formBasicPassword">
                      <Form.Control type="text" placeholder="Sub-District" value={SubDistrict} onChange={(e) => { setSubDistrict(e.target.value) }} />
                    </Form.Group>
                  </Col>

                  <Col>
                    <Form.Group controlId="formBasicPassword">
                      <Form.Control type="text" placeholder="Size" value={Size} onChange={(e) => { setSize(e.target.value) }} />
                    </Form.Group>
                  </Col>
                  <Col>
                    <Form.Group controlId="exampleForm.SelectCustom">

                      <Form.Control as="select" custom onChange={(e) => { setcheckboxtype(e.target.value) }}>
                        <option >Market approch</option>
                        <option >Machine Learning</option>
                      </Form.Control>
                    </Form.Group>
                  </Col>
                </Row>
                <Row style={{ marginTop: "20px" }}>
                  <Col>
                    <Form.Group controlId="exampleForm.SelectCustom">

                      <Form.Control as="select" custom onChange={(e) => { setcheckboxtype2(e.target.value) }}>
                        <option >ที่ดินเปล่า</option>
                        <option >ที่ดินพร้อมสิ่งปลูกสร้าง</option>
                        <option >ห้องชุด</option>
                      </Form.Control>
                    </Form.Group>
                  </Col>

                  <Col>
                    <Form.Group controlId="formBasicPassword">
                      <Form.Control type="text" placeholder="City Plan Color" value={CityPlanColor} onChange={(e) => { setCityPlanColor(e.target.value) }} />
                    </Form.Group>
                  </Col>
                  <Col>
                  </Col>
                </Row>
                <Row style={{ marginTop: "20px" }}>
                  <Col>
                    <Form.Group controlId="formBasicPassword">
                      <Form.Control type="text" placeholder="Longitude,Latitude" value={latlong} onChange={(e) => { setlatlong(e.target.value) }} />
                    </Form.Group>
                  </Col>

                  <Col>
                    <Row>
                      <Col>
                        <Button style={{ width: "100%" }} onClick={clickAgree} variant="primary" type="submit">
                          Agree
  </Button>
                      </Col>
                      <Col>
                        <Button style={{ width: "100%" }} variant="danger" type="submit" onClick={clickCancel}>
                          Cancel
  </Button>
                      </Col>
                    </Row>
                  </Col>
                  <Col>

                  </Col>
                </Row>
              </Col>
            </Row>
          </Col>


        </Row>

      </div>
    </>
  );
}

export default Test;
