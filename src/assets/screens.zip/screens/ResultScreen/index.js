import { Row, Col, Button, Form } from 'react-bootstrap'
import imgtest1 from "../../images/consignment_img1.jpg"
import imgtest2 from "../../images/consignment_img2.jpg"
import imgtest3 from "../../images/consignment_img3.jpg"
import f from "../../images/Artboard 1.png"
import { ProSidebar, Menu, MenuItem, SubMenu } from 'react-pro-sidebar';
import 'react-pro-sidebar/dist/css/styles.css';
import { Link } from 'react-router-dom';
import { useLocation } from 'react-router-dom'
import React from 'react'


function Test(props) {
    const [nearby,setNearby] = React.useState()
    const location = useLocation();
    console.log(location)


    const nearbyClick = ()=>{
        var nearArr = location.state.nearBy
        var nearString=null

        for(var i =0; i< nearArr.length;i++){
         i == 0 ? nearString =  nearArr[i].uid :  nearString =nearString + ","+nearArr[i].uid
           
        }

        setNearby(nearString)
    
    }





    return (
        <>
            <div style={{ backgroundColor: "#66BECC", height: "100vh" }}>
                <Row style={{
                    margin: 0, height: "100%", backgroundImage: `url("https://sv1.picz.in.th/images/2021/04/01/DJnLX9.png")`,
                }}>
                    <Col  >
                        <ProSidebar style={{ margin: 0, height: '1000px', width: '100%' }}>

                            <Menu iconShape="square">
                                <MenuItem  >Pramern</MenuItem>
                                <Link to="/" />
                                <SubMenu title="MENU" >
                                    <MenuItem>PROPERTY APPRAISAL<Link to="/test" /></MenuItem>
                                    <MenuItem>CONSIGNMENT<Link to="/Consignment" /></MenuItem>
                                    <MenuItem>CONSIGNMENT LIST<Link to="/ConsignmentLists" /></MenuItem>
                                </SubMenu>
                            </Menu>

                        </ProSidebar>


                    </Col>

                    <Col sm={10} className="d-flex justify-content-center align-items-center" style={{ margin: 0, padding: 50, backgroundImage: `url("https://sv1.picz.in.th/images/2021/04/01/DJslzn.png")`, backgroundPosition: 'center', backgroundRepeat: 'no-repeat', backgroundSize: 'cover' }}>

                        <div style={{ width: "100%", height: "100%",  backgroundColor: "#736E76", borderRadius: 10, boxShadow: "5px 5px 10px #9E9E9E", border: 'solid white' }}>
                            <Row>
                                <Col>
                                <div  style={{ marginLeft: '60px' ,marginTop: '35px' ,width:"70%"}}>
                                
                                <div className="form-group">
                                <label htmlFor="">Province</label>
                                <input type="text" name="address" value={location.state.province} className="form-control" readOnly="readOnly" />
                                </div>
                                <div className="form-group">
                                <label htmlFor="">District</label>
                                <input type="text" name="state" value={location.state.district} className="form-control"  readOnly="readOnly" />
                                </div>
                                
                                <div className="form-group">
                                <label htmlFor="">Sub-district</label>
                                <input type="text" name="area" value={location.state.sub_district} className="form-control"  readOnly="readOnly" />
                                </div>
                                <div className="form-group">
                                <label htmlFor="">Type</label>
                                <input type="text" name="city" value={location.state.prop_type} className="form-control"  readOnly="readOnly" />
                                </div>
                                <div className="form-group">
                                <label htmlFor="">City Plan Color</label>
                                <input type="text" name="cit_plan_color" value={location.state.cit_plan_color} className="form-control"  readOnly="readOnly" />
                                </div>
                                
                                
                                <div className="form-group">
                                <label htmlFor="">Size</label>
                                <input type="text" name="address" value={location.state.size} className="form-control" readOnly="readOnly" />
                                </div>
                                
                                <Button style={{width:"100%" ,marginTop:'70px' } } onClick={nearbyClick}  variant="danger" /* type="submit"*/>
                                    Facility
                                </Button>
                                </div>
                                </Col>
                                <Col>
                                <div style={{ marginLeft: '60px' ,marginTop: '35px' ,width:"70%"}}>
                               <div className="form-group">
         <label htmlFor="">Evaluation method  
</label>
         <input type="text" name="address" value={location.state.eval} className="form-control" readOnly="readOnly" />
        </div>
        <div className="form-group">
         <label htmlFor="">Appraisal price </label>
         <input type="text" name="address" value={location.state.price} className="form-control" readOnly="readOnly" />
        </div>
        <div className="form-group">
         <label htmlFor="">Nearby </label>
         <input type="text" name="address" style={{height:'250px'}} value={nearby} className="form-control" readOnly="readOnly" />
        </div>
        </div>
                                
                                </Col>

                            </Row>
                           


                        </div>
                    </Col>


                </Row>
            </div>
        </>
    );
}

export default Test;
