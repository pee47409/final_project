import React,{Component} from 'react'
import { withGoogleMap, GoogleMap, withScriptjs, InfoWindow, Marker } from "react-google-maps";
import Geocode from "react-geocode";
import { Row, Col, Button, Form } from 'react-bootstrap'
import GoogleMapReact from 'google-map-react';
import Autocomplete from 'react-google-autocomplete';
import { ProSidebar, Menu, MenuItem, SubMenu } from 'react-pro-sidebar';
import { Link } from 'react-router-dom';
import axios from "axios";
import { withRouter } from 'react-router-dom';
Geocode.setApiKey("AIzaSyC4rXwXvSbKJ7NCT7EZnQ334Ef4EUTFEo0");
Geocode.enableDebug();


class Map extends React.Component{
  constructor( props ){
    super( props );
    this.state = {
     address: '',
     city: '',
     area: '',
     state: '',
     size:'',
     type:'ที่ดินเปล่า',
     eval:'Market Approach',
     citycolor:'',
     mapPosition: {
      lat: this.props.center.lat,
      lng: this.props.center.lng
     },
     markerPosition: {
      lat: this.props.center.lat,
      lng: this.props.center.lng
  }
    }
    
    
   }
   
  
  /**
    * Get the current address from the default map position and set those values in the state
    */
   componentDidMount() {
    Geocode.fromLatLng( this.state.mapPosition.lat , this.state.mapPosition.lng ).then(
     response => {
      const address = response.results[0].formatted_address,
       addressArray =  response.results[0].address_components,
       city = this.getCity( addressArray ),
       area = this.getArea( addressArray ),
       state = this.getState( addressArray ),
       lat = this.state.markerPosition.lat,
       lng = this.state.markerPosition.lng;
    
      console.log( 'city', city, area, state );
      console.log("+++++++++++++++++++++++++++");
      console.log(addressArray);
     
    
      this.setState( {
       address: ( address ) ? address : '',
       area: ( area ) ? area : '',
       city: ( city ) ? city : '',
       state: ( state ) ? state : '',
        markerPosition: {
      lat: ( lat ) ? lat : '',
      lng:  ( lng ) ? lng : '',
  }
      } )
     },
     error => {
      console.error(error);
     }
    );
   };
  /**
    * Component should only update ( meaning re-render ), when the user selects the address, or drags the pin
    *
    * @param nextProps
    * @param nextState
    * @return {boolean}
    */
   shouldComponentUpdate( nextProps, nextState ){
    if (
     this.state.markerPosition.lat !== this.props.center.lat ||
     this.state.address !== nextState.address ||
     this.state.city !== nextState.city ||
     this.state.area !== nextState.area ||
     this.state.state !== nextState.state
    ) {
     return true
    } else if ( this.props.center.lat === nextProps.center.lat ){
     return false
    }
   }
  /**
    * Get the city and set the city input value to the one selected
    *
    * @param addressArray
    * @return {string}
    */
   getCity = ( addressArray ) => {
    
     
      let city = '';
    for( let i = 0; i < addressArray.length; i++ ) {
     if ( addressArray[ i ].types[0]  ) {
      for ( let j = 0; j < addressArray[ i ].types.length; j++ ) {
       if ( 'sublocality_level_2' === addressArray[ i ].types[j] || 'locality' === addressArray[ i ].types[j] ) {
        city = addressArray[ i ].long_name;
        
        
        
        return city;
        
       }
      }
     }
    }
      
     };
    
   
   
  /**
    * Get the area and set the area input value to the one selected
    *
    * @param addressArray
    * @return {string}
    */
   getArea = ( addressArray ) => {
    let area = '';
    for( let i = 0; i < addressArray.length; i++ ) {
     if ( addressArray[ i ].types[0]  ) {
      for ( let j = 0; j < addressArray[ i ].types.length; j++ ) {
       if ( 'sublocality_level_1' === addressArray[ i ].types[j] || 'locality' === addressArray[ i ].types[j] ) {
        area = addressArray[ i ].long_name;
        
        
        
        return area;
        
       }
      }
     }
    }
   };
  /**
    * Get the address and set the address input value to the one selected
    *
    * @param addressArray
    * @return {string}
    */
   getState = ( addressArray ) => {
    let state = '';
    for( let i = 0; i < addressArray.length; i++ ) {
     for( let i = 0; i < addressArray.length; i++ ) {
      if ( addressArray[ i ].types[0] && 'administrative_area_level_1' === addressArray[ i ].types[0] ) {
       state = addressArray[ i ].long_name;
       return state;
      }
     }
    }
   };
  /**
    * And function for city,state and address input
    * @param event
    */
   onChange = ( event ) => {
    this.setState({ [event.target.name]: event.target.value });
   };
  /**
    * This Event triggers when the marker window is closed
    *
    * @param event
    */
   onInfoWindowClose = ( event ) => {
  };
  /**
    * When the user types an address in the search box
    * @param place
    */
   onPlaceSelected = ( place ) => {
  const address = place.formatted_address,
     addressArray =  place.address_components,
     city = this.getCity( addressArray ),
     area = this.getArea( addressArray ),
     state = this.getState( addressArray ),
     latValue = place.geometry.location.lat(),
     lngValue = place.geometry.location.lng();
  // Set these values in the state.
    this.setState({
     address: ( address ) ? address : '',
     area: ( area ) ? area : '',
     city: ( city ) ? city : '',
     state: ( state ) ? state : '',
     markerPosition: {
      lat: latValue,
      lng: lngValue
     },
     mapPosition: {
      lat: latValue,
      lng: lngValue
     },
    })
   };
   
  /**
    * When the marker is dragged you get the lat and long using the functions available from event object.
    * Use geocode to get the address, city, area and state from the lat and lng positions.
    * And then set those values in the state.
    *
    * @param event
    */
   onMarkerDragEnd = ( event ) => {
    console.log( 'event', event );
    let newLat = event.latLng.lat(),
     newLng = event.latLng.lng(),
     addressArray = [];
  Geocode.fromLatLng( newLat , newLng ).then(
     response => {
      const address = response.results[0].formatted_address,
       addressArray =  response.results[0].address_components,
       city = this.getCity( addressArray ),
       area = this.getArea( addressArray ),
       state = this.getState( addressArray );
       
  this.setState( {
       address: ( address ) ? address : '',
       area: ( area ) ? area : '',
       city: ( city ) ? city : '',
       state: ( state ) ? state : ''
      } )
     },
     error => {
      console.error(error);
     }
    );
   };

   onSubmit = async ()=>{
    console.log("Click")
    console.log(this.state.state)
    console.log(this.state.area)
    console.log(this.state.city)
    console.log(this.state.markerPosition.lat)
    console.log(this.state.markerPosition.lng)
    console.log(this.state.size)
    console.log(this.state.eval)
    console.log(this.state.type)
    console.log(this.state.citycolor)
 
    var typenum = 1
    if(this.state.type === "ที่ดินเปล่า"){
      typenum=1
    }
    else if(this.state.type === "ที่ดินพร้อมสิ่งปลูกสร้าง"){
      typenum=2
    }
    else if(this.state.type === "ห้องชุด"){
      typenum=3
    }
    try {
     var respond = await axios({
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin":"*",
        },
        data:{
          'province'    :   this.state.state,
          'district'    :   this.state.area,
          'sub_district' :   this.state.city,
          'size'        :   this.state.size,
          'prop_type'        :   typenum,
          'cit_plan_color': this.state.citycolor,
          'geom'        :   "POINT ("+this.state.markerPosition.lng+" "+this.state.markerPosition.lat+")"
        },
        url:
          "http://10.0.2.2:5001/siit-gate-api/us-central1/app/api/login-reg" ////// api url ของ appr_price
   
      });

      var nearBy = await axios({
        method: "GET",
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin":"*",
        },
        data:{
          'province'    :   this.state.state,
          'district'    :   this.state.area,
          'sub_district' :   this.state.city,
          'size'        :   this.state.size,
          'prop_type'        :   typenum,
          'cit_plan_color': this.state.citycolor,
          'geom'        :   "POINT ("+this.state.markerPosition.lng+" "+this.state.markerPosition.lat+")"
        },
        url:
          "http://10.0.2.2:5001/siit-gate-api/us-central1/app/api/login-reg" ///// api url ของ category ID
   
      });


      alert("Sending Completed")
    }
    catch(err){
      alert("Fail sending api:"+err)
      console.log("Fail sending api:" + err)
    }
    /// เเบบจำลองข้อมูล
 /*   var apPrice=2000
    this.props.history.push({
      pathname: `/ResultScreen`,
      state: {
        'province'    :   this.state.state,
        'district'    :   this.state.area,
        'sub_district' :   this.state.city,
        'size'        :   this.state.size,
        'prop_type'        :   this.state.type ,
        'cit_plan_color': this.state.citycolor,
        'eval':this.state.eval,
        'price':apPrice,
        'nearBy':[{'id': 149, 'uid': 'airport', 'desc': 'ตำแหน่งที่ตั้งสนามบิน', 'type': 'point'}, {'id': 150, 'uid': 'airportlink_line', 'desc': 'เส้นทางรถไฟฟ้าท่าอากาศยานสุวรรณภูมิ', 'type': 'linestring'}, {'id': 151, 'uid': 'airportlink_station', 'desc': 'สถานีรถไฟฟ้า', 'type': 'point'}, {'id': 152, 'uid': 'bike_way', 'desc': 'ทางรถจักรยาน', 'type': 'linestring'}, {'id': 153, 'uid': 'bma_expess', 'desc': 'ศูนย์บริการด่วนมหานคร', 'type': 'point'}, {'id': 154, 'uid': 'bma_office', 'desc': 'หน่วยงานใน กทม.', 'type': 'point'}, {'id': 155, 'uid': 'bma_school', 'desc': 'โรงเรียนใน กทม.', 'type': 'point'}, {'id': 156, 'uid': 'bma_training', 'desc': 'ศูนย์ฝึกอบรม กทม.', 'type': 'point'}, {'id': 157, 'uid': 'bma_zone', 'desc': 'พื้นที่ กทม.', 'type': 'polygon'}, {'id': 158, 'uid': 'brt_line', 'desc': 'เส้นทางเดินรถ BRT', 'type': 'linestring'}, {'id': 159, 'uid': 'brt_station', 'desc': 'สถานีรถไฟฟ้า BRT', 'type': 'point'}, {'id': 160, 'uid': 'bts_line', 'desc': 'เส้นทางเดินรถ BTS', 'type': 'linestring'}, {'id': 161, 'uid': 'bts_station', 'desc': 'สถานีรถไฟฟ้า BTS', 'type': 'point'}, {'id': 162, 'uid': 'department_store', 'desc': 'ห้างสรรพสินค้า ใน กทม.', 'type': 'point'}, {'id': 163, 'uid': 'district', 'desc': 'เขตใน กทม.', 'type': 'polygon'}, {'id': 164, 'uid': 'hotel', 'desc': 'โรงแรม', 'type': 'point'}, {'id': 165, 'uid': 'land_value', 'desc': 'ราคาประเมิน', 'type': 'point'}, {'id': 166, 'uid': 'market', 'desc': 'ตลาด', 'type': 'point'}, {'id': 167, 'uid': 'mea_office', 'desc': 'ที่ทำการไฟฟ้า', 'type': 'point'}, {'id': 168, 'uid': 'ministry', 'desc': 'หน่วยงานราชการ', 'type': 'point'}, {'id': 169, 'uid': 'mrt_line', 'desc': 'เส้นทางเดินรถ MRT', 'type': 'linestring'}, {'id': 170, 'uid': 'mrt_station', 'desc': 'สถานีรถไฟฟ้า MRT', 'type': 'point'}, {'id': 171, 'uid': 'mwa_area', 'desc': 'พื้นที่รับผิดชอบของการประปา', 'type': 'polygon'}, {'id': 172, 'uid': 'mwa_office', 'desc': 'ที่ทำการของกองประปา', 'type': 'point'}, {'id': 173, 'uid': 'police_area', 'desc': 'สถานีตำรวจ', 'type': 'polygon'}, {'id': 174, 'uid': 'police_station', 'desc': 'สถานีตำรวจ', 'type': 'point'}, {'id': 175, 'uid': 'public_park', 'desc': 'สถานีตำรวจ', 'type': 'point'}]
  
      }*/


////เเบบที่จะใช้งานจริง
      var apPrice = respond.appr_price
      this.props.history.push({
        pathname: `/ResultScreen`,
        state: {
          'province'    :   this.state.state,
          'district'    :   this.state.area,
          'sub_district' :   this.state.city,
          'size'        :   this.state.size,
          'prop_type'        :   this.state.type ,
          'cit_plan_color': this.state.citycolor,
          'eval':this.state.eval,
          'price':apPrice,
          'nearBy':nearBy
        }
  });
    
  }
  render(){
    

  const AsyncMap = withScriptjs(
     withGoogleMap(
      props => (
       <GoogleMap google={this.props.google}
        defaultZoom={this.props.zoom}
        defaultCenter={{ lat: this.state.mapPosition.lat, lng: this.state.mapPosition.lng }}
       >
        {/* For Auto complete Search Box */}
        <Autocomplete
         style={{
          width: '100%',
          height: '40px',
          paddingLeft: '16px',
          marginTop: '2px',
          marginBottom: '100px'
         }}
         onPlaceSelected={ this.onPlaceSelected }
         types={['(regions)']}
        />
  {/*Marker*/}
        <Marker google={this.props.google}
         name={'Dolores park'}
            draggable={true}
            onDragEnd={ this.onMarkerDragEnd }
               position={{ lat: this.state.markerPosition.lat, lng: this.state.markerPosition.lng }}
        />
        <Marker />
  {/* InfoWindow on top of marker */}
        <InfoWindow
         onClose={this.onInfoWindowClose}
         position={{ lat: ( this.state.markerPosition.lat + 0.0018 ), lng: this.state.markerPosition.lng }}
        >
         <div>
          <span style={{ padding: 0, margin: 0 }}>{ this.state.address }</span>
         </div>
        </InfoWindow>
  </GoogleMap>
  )
     )
    );
  let map;
    if( this.props.center.lat !== undefined ) {
     map = <div>
       {/* <div>
        <div className="form-group">
         <label htmlFor="">City</label>
         <input type="text" name="city" className="form-control" onChange={ this.onChange } readOnly="readOnly" value={ this.state.city }/>
        </div>
        <div className="form-group">
         <label htmlFor="">Area</label>
         <input type="text" name="area" className="form-control" onChange={ this.onChange } readOnly="readOnly" value={ this.state.area }/>
        </div>
        <div className="form-group">
         <label htmlFor="">State</label>
         <input type="text" name="state" className="form-control" onChange={ this.onChange } readOnly="readOnly" value={ this.state.state }/>
        </div>
        <div className="form-group">
         <label htmlFor="">Address</label>
         <input type="text" name="address" className="form-control" onChange={ this.onChange } readOnly="readOnly" value={ this.state.address }/>
        </div>
       </div> */
       <>
      <div style={{ backgroundColor: "#66BECC", height: "100vh" }}>
        <Row style={{ margin: 0, height: "100%" ,backgroundImage:`url("https://sv1.picz.in.th/images/2021/04/01/DJnLX9.png")`,
     }}>
          <Col  >
          <ProSidebar style={{ margin: 0, height: '1000px' ,width:'100%' }}>
         
          <Menu iconShape="square">
          <MenuItem  >Pramern</MenuItem>
          <Link to="/" />
          <SubMenu title="MENU" >
            
          <MenuItem>PROPERTY APPRAISAL<Link to="/test" /></MenuItem>
          <MenuItem>CONSIGNMENT<Link to="/Consignment" /></MenuItem>
          <MenuItem>CONSIGNMENT LIST<Link to="/ConsignmentLists" /></MenuItem>
          </SubMenu>
          </Menu>
          
          </ProSidebar>
          
         
          </Col>

          <Col sm={10} style={{  padding: 20,backgroundImage:`url("https://sv1.picz.in.th/images/2021/04/01/DJslzn.png")`,backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundSize:'cover'}}>
            
            <div style={{ height: "650px", backgroundColor: "#736E76", borderRadius: 10, boxShadow: "5px 5px 10px #9E9E9E",border:'solid white' }}>
          


         {    <AsyncMap
        googleMapURL="https://maps.googleapis.com/maps/api/js?key=AIzaSyC4rXwXvSbKJ7NCT7EZnQ334Ef4EUTFEo0&libraries=places"
        loadingElement={
         <div style={{ height: `100%` }} />
        }
        containerElement={
         <div style={{ height: this.props.height }} />
        }
        mapElement={
         <div style={{ height: `86%` }} />
         
        }
       />}
     
    
            </div>
            
            <Row sm>
              <Col sm style={{marginTop:"15px"}}>
              <Row >
                <Col>
                <Form.Group controlId="formBasicPassword">
  
    <Form.Control type="text" placeholder="Province" value={this.state.state} /*onChange={(e)=>{setProvince(e.target.value)}}*/ />
  </Form.Group>
 
  
                </Col>
                
                <Col>
                <Form.Group controlId="formBasicPassword">
    <Form.Control type="text" placeholder="District" value={this.state.area} /*value={District} onChange={(e)=>{setDistrict(e.target.value)}}*/ />
  </Form.Group>
                </Col>
                <Col>
{/*ที่เว้น */}
                </Col>
              </Row>
              <Row style={{marginTop:"20px"}}>
                <Col>
                <Form.Group controlId="formBasicPassword">
    <Form.Control type="text" placeholder="Sub-District" value={this.state.city} /*value={SubDistrict} onChange={(e)=>{setSubDistrict(e.target.value)}}*/ />
  </Form.Group>
                </Col>
                
                <Col>
                <Form.Group controlId="formBasicPassword">
    <Form.Control type="text" placeholder="Size" onChange={(e)=> this.setState({size:e.target.value})} />
  </Form.Group>
                </Col>
                <Col>
                <Form.Group controlId="exampleForm.SelectCustom">

<Form.Control as="select" onChange={(e)=> this.setState({eval:e.target.value})} >
  <option >Market approch</option>
  <option >Machine Learning</option>
</Form.Control>

</Form.Group>
                </Col>
              </Row>
              <Row style={{marginTop:"20px"}}>
                <Col>
                <Form.Group controlId="exampleForm.SelectCustom">

                      <Form.Control as="select" custom onChange={(e)=> this.setState({type:e.target.value})}>
                        <option >ที่ดินเปล่า</option>
                        <option >ที่ดินพร้อมสิ่งปลูกสร้าง</option>
                        <option >ห้องชุด</option>
                      </Form.Control>
                    </Form.Group>
                </Col>
                
                <Col>
                <Form.Group controlId="formBasicPassword">
    <Form.Control type="text" placeholder="City Plan Color"onChange={(e)=> this.setState({citycolor:e.target.value})}/>
  </Form.Group>
                </Col>
                <Col>
                </Col>
              </Row>
              <Row style={{marginTop:"20px"}}>
                <Col>
                <Form.Group controlId="formBasicPassword">
    <Form.Control type="text" placeholder="Longitude,Latitude"  value={this.state.markerPosition.lng+","+this.state.markerPosition.lat} /* value={latlong} onChange={(e)=>{setlatlong(e.target.value)}} *//>
  </Form.Group>
                </Col>
                
                <Col>
<Row>
  <Col>
  <Button style={{width:"100%"}} onClick={this.onSubmit} variant="success"/* type="submit"*/>
    Next
  </Button>
  </Col>
  <Col>
  <Button style={{width:"100%"}}variant="danger"  href='/'  variant="secondary"/*type="submit"  onClick={clickCancel}*/>
   Home
  </Button>
  </Col>
</Row>
                </Col>
                <Col>

                </Col>
              </Row>
              </Col>
           </Row>
          </Col>
        
       
        </Row>
        
      </div>

      
      
    </>
       }
   
      </div>
  } else {
     map = <div style={{height: this.props.height}} />
    }
    return( map )
    
   }
  }
  export default withRouter(Map)