import { Row, Col, Button, Form } from 'react-bootstrap'
import imgtest from "../../images/hey.png"
import f from "../../images/Artboard 1.png"
import { ProSidebar, Menu, MenuItem, SubMenu } from 'react-pro-sidebar';
import 'react-pro-sidebar/dist/css/styles.css';
import { Link } from 'react-router-dom';
import GoogleMapReact from 'google-map-react';
import React,{Component} from 'react'
import { withGoogleMap, GoogleMap, withScriptjs, InfoWindow, Marker } from "react-google-maps";
import Geocode from "react-geocode";
import Autocomplete from 'react-google-autocomplete';
import Map from './Map';

class Test extends Component {
  componentDidMount(){
    console.log("-------");
    
    
  }

/*function Test() {
  const [Province, setProvince] = React.useState(null)
  const [District, setDistrict] = React.useState(null)
  const [SubDistrict, setSubDistrict] = React.useState(null)
  const [Size, setSize] = React.useState(null)
  const [Type, setType] = React.useState(null)
  const [CityPlanColor, setCityPlanColor] = React.useState(null)
  const [latlong, setlatlong] = React.useState(null)
  const [checkboxtype, setcheckboxtype] = React.useState("Marketapproch")




  const clickAgree =()=>{

  

      var Checkboxtype = checkboxtype

      if(Province != null && District != null && SubDistrict != null  && Size != null && Type != null && CityPlanColor != null && latlong != null  ){

        console.log(Province)
        console.log(District)
        console.log(SubDistrict)
        console.log(Size)
        console.log(Type)
        console.log(CityPlanColor)
        console.log(latlong)
        console.log(Checkboxtype)
        

      }
      else{
        alert("Please fill all information")
      }

    
  }
  
  const clickCancel =()=>{setProvince(null)
  setSubDistrict(null)
  setSize(null)
  setDistrict(null)
  setType(null)
  setCityPlanColor(null)
  }*/
  render() {


  return (
    <div>

     
        <Map
                    google={this.props.google}
                    center={{ lat: 13.736717, lng: 100.523186 }}
                    height='700px'
                    zoom={13}
        />
    </div>
           
  );
}
}

export default Test;
