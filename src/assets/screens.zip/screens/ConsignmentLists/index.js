import { Row, Col, Button, Form } from 'react-bootstrap'
import imgtest1 from "../../images/consignment_img1.jpg"
import imgtest2 from "../../images/consignment_img2.jpg"
import imgtest3 from "../../images/consignment_img3.jpg"
import f from "../../images/Artboard 1.png"
import { ProSidebar, Menu, MenuItem, SubMenu } from 'react-pro-sidebar';
import 'react-pro-sidebar/dist/css/styles.css';
import { Link } from 'react-router-dom';


function Test() {
  return (
    <>
      <div style={{ backgroundColor: "#66BECC", height: "100vh" }}>
        <Row style={{
          margin: 0, height: "100%", backgroundImage: `url("https://sv1.picz.in.th/images/2021/04/01/DJnLX9.png")`,
        }}>
          <Col  >
            <ProSidebar style={{ margin: 0, height: '1000px', width: '100%' }}>

              <Menu iconShape="square">
                <MenuItem  >Pramern</MenuItem>
                <Link to="/" />
                <SubMenu title="MENU" >
                  <MenuItem>PROPERTY APPRAISAL<Link to="/test" /></MenuItem>
                  <MenuItem>CONSIGNMENT<Link to="/Consignment" /></MenuItem>
                  <MenuItem>CONSIGNMENT LIST<Link to="/ConsignmentLists" /></MenuItem>
                </SubMenu>
              </Menu>

            </ProSidebar>


          </Col>

          <Col sm={10} className="d-flex justify-content-center align-items-center" style={{ margin: 0, padding: 50, backgroundImage: `url("https://sv1.picz.in.th/images/2021/04/01/DJslzn.png")`, backgroundPosition: 'center', backgroundRepeat: 'no-repeat', backgroundSize: 'cover' }}>

            <div style={{ width: "100%", height: "100%", overflowY: 'scroll', backgroundColor: "#736E76", borderRadius: 10, boxShadow: "5px 5px 10px #9E9E9E", border: 'solid white' }}>
              <Row style={{ margin: 10 }}>
                <Col>
                  <p className="h1" style={{ color: 'white' }}>
                    Consignment list
         </p>
                </Col>
              </Row>

              {/*ดึงข้อมูลมาจาก database */}

              <Row style={{ margin: 30, height: "200px" }}>
                <Col sm={4} style={{ height: "100%" }} className="d-flex justify-content-center align-items-center"><img src={imgtest1} style={{ maxHeight: "100%" }} /></Col>

                <Col sm={8} style={{ backgroundColor: "white" }}>

                  <p>  กรุงเทพฯ, หลักสี, ทุ่งสองห้อง, 10484 ตร.ม., ที่ดินเปล่า, พื้นที่สีแดง <br/>
                    (100.5561,13.8958)
                  <br/>
                  5,000,000 Baht
                  </p>


                 2 weeks ago
        </Col>
              </Row>
              <Row style={{ margin: 30, height: "200px" }}>
                <Col sm={4} style={{ height: "100%" }} className="d-flex justify-content-center align-items-center"><img src={imgtest2} style={{ maxHeight: "100%" }} /></Col>
                <Col sm={8} style={{ backgroundColor: "white" }}>

                <p> นนทบุรี, บางใหญ่, บางใหญ่, 9084 ตร.ม., ที่ดินเปล่า, พื้นที่สีแดง <br/>
                    (100.404118,13.874340)
                  <br/>
                  3,500,000 Baht
                  </p>


                 3 weeks ago
        </Col>
              </Row>
              <Row style={{ margin: 30, height: "200px" }}>
                <Col sm={4} style={{ height: "100%" }} className="d-flex justify-content-center align-items-center"><img src={imgtest3} style={{ maxHeight: "100%" }} /></Col>
                <Col sm={8} style={{ backgroundColor: "white" }}>

                <p> ปทุมธานี, คลองหลวง, บางหวาย, 10410 ตร.ม., ที่ดินเปล่า, พื้นที่สีเหลือง <br/>
                    (100.766112,14.150578)
                  <br/>
                  4,000,000 Baht
                  </p>



                 1 weeks ago
        </Col>
              </Row>



            </div>
          </Col>


        </Row>
      </div>
    </>
  );
}

export default Test;
